using ProjCondominios.UI_Layer;
using ProjCondominios.Services;
using ProjCondominios.Models;
using ProjCondominios.Interfaces;
using System.Collections.Generic;

namespace ProjCondominios
{
    public partial class MenuPrincipal : Form
    {
        private readonly FileService _fileService;
        private readonly List<Condominio> _condominios;
        private readonly CondominioService _condominioService;
        private readonly CondominoService _condominoService;
        private readonly FracaoAutonomaService _fracaoService;
        private readonly ReservaService _reservaService;
        private readonly ReuniaoService _reuniaoService;
        private readonly RelatorioService _relatorioService;
        private readonly DespesaService _despesaService;
        private readonly PagamentoService _pagamentoService;

        // Construtor �nico que inicializa todos os servi�os necess�rios
        public MenuPrincipal()
        {
            InitializeComponent();

            // Inicializar servi�os compartilhados
            _fileService = new FileService();
            _condominioService = new CondominioService();
            _condominoService = new CondominoService();
            //_relatorioService = new RelatorioService(); 
            _reuniaoService = new ReuniaoService(_relatorioService);
            _fracaoService = new FracaoAutonomaService(_condominioService, _condominoService, _fileService, new List<FracaoAutonoma>());
            _reservaService = new ReservaService();
            _despesaService = new DespesaService();
            _pagamentoService = new PagamentoService();
            _condominios = _condominioService.ObterCondominios();
        }

        // Carregar os dados ao abrir o formul�rio
        private void MenuPrincipal_Load(object sender, EventArgs e)
        {
            // Carregar dados iniciais 
            var condominios = _condominioService.Condominios;
            var condominos = _condominoService.Condominos;
            var fracoes = _fracaoService.ListarTodasFracoes();
        }
        
        private void fecharToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void GestaoCondominiosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Passa os servi�os necess�rios ao formul�rio de gest�o de condom�nios
            var formGestaoCondominios = new GestaoCondominios(_condominioService, this);
            formGestaoCondominios.Show();
        }

        private void GestaoCondominosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Passa os servi�os necess�rios ao formul�rio de gest�o de cond�minos
            var formGestaoCondominos = new GestaoCondominos(_condominoService, this);
            formGestaoCondominos.Show();
        }

        private void GestaoFracoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Passa os servi�os necess�rios ao formul�rio de gest�o de fra��es
            var formGestaoFracoes = new GestaoFracoes(_fracaoService, _condominioService, _condominoService, this);
            formGestaoFracoes.Show();
        }

        private void GestaoReservasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Passa os servi�os necess�rios ao formul�rio de gest�o de reservas
            var formGestaoReservas = new GestaoReservas(_reservaService, _condominioService, _condominoService, this);
            formGestaoReservas.Show();
        }

        private void GestaoReunioesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Passa os servi�os necess�rios ao formul�rio de gest�o de reuni�es
            var formGestaoReunioes = new GestaoReunioes(_reuniaoService, _relatorioService, this);
            formGestaoReunioes.Show();
        }

        private void GestaoDespesasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var formGestaoDespesas = new GestaoDespesas(_despesaService, _condominios, this);
            formGestaoDespesas.Show();
        }

        private void GestaoPagamentosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var formGestaoPagamentos = new GestaoPagamentos(_pagamentoService, _condominios, this);
            formGestaoPagamentos.Show();
        }

        private void GestaoFinanceiraToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void RelatoriosFinanceirosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        
    }
}